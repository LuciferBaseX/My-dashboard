"use client"

import Dashboard from "../page"

export default function SyntheticV0PageForDeployment() {
  return <Dashboard />
}