import Layout from "./layout"
import { WelcomeCard } from "./components/welcome-card"
import { ServiceCard } from "./components/service-card"
import { MetricsGrid } from "./components/metrics-card"
import { ProgressChart } from "./components/progress-chart"

export default function Dashboard() {
  return (
    <Layout>
      <div className="grid gap-6 lg:grid-cols-[300px,1fr]">
        <WelcomeCard />
        <div className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <ServiceCard
              title="Contract Execution Upload"
              description="Lorem ipsum dolor sit amet consectetur. Senectus sed urna ac tempus ornare."
            />
            <ServiceCard
              title="E-Stamp Services"
              description="Lorem ipsum dolor sit amet consectetur. Morbi adipiscing vulputate morbid..."
            />
            <ServiceCard
              title="E-Sign Services"
              description="Lorem ipsum dolor sit amet consectetur. Mauris enim pulvinar interdum augue eu."
            />
          </div>
          <div className="flex items-center justify-between">
            <select className="rounded-md border bg-white px-3 py-2 text-sm">
              <option>All branches</option>
            </select>
            <div className="flex items-center gap-2">
              <select className="rounded-md border bg-white px-3 py-2 text-sm">
                <option>Custom range</option>
              </select>
              <select className="rounded-md border bg-white px-3 py-2 text-sm">
                <option>March 2020</option>
              </select>
            </div>
          </div>
          <div>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold">Order Details</h2>
              <button className="text-sm text-purple-600">View All</button>
            </div>
            <MetricsGrid />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <ProgressChart title="E-sign Count" percentage={30} subtitle="20 orders pending" />
            <ProgressChart title="E-stamp Count" percentage={30} />
          </div>
        </div>
      </div>
    </Layout>
  )
}

