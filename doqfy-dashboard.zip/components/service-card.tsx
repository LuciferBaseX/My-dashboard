interface ServiceCardProps {
  title: string
  description: string
}

export function ServiceCard({ title, description }: ServiceCardProps) {
  return (
    <div className="rounded-lg border bg-white p-6">
      <h3 className="mb-2 text-lg font-semibold">{title}</h3>
      <p className="mb-4 text-sm text-gray-500">{description}</p>
      <button className="text-sm font-medium text-purple-600 hover:text-purple-700">Get started →</button>
    </div>
  )
}

