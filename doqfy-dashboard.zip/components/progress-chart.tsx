interface ProgressChartProps {
  title: string
  percentage: number
  subtitle?: string
}

export function ProgressChart({ title, percentage, subtitle }: ProgressChartProps) {
  const circumference = 2 * Math.PI * 40
  const offset = circumference - (percentage / 100) * circumference

  return (
    <div className="rounded-lg border bg-white p-6">
      <h3 className="mb-4 text-lg font-semibold">{title}</h3>
      <div className="flex items-center justify-between">
        <div className="relative h-24 w-24">
          <svg className="h-full w-full -rotate-90" viewBox="0 0 100 100">
            <circle className="stroke-gray-200" cx="50" cy="50" r="40" strokeWidth="10" fill="none" />
            <circle
              className="stroke-purple-600 transition-all duration-1000 ease-in-out"
              cx="50"
              cy="50"
              r="40"
              strokeWidth="10"
              fill="none"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-lg font-bold">{percentage}%</span>
          </div>
        </div>
        {subtitle && <div className="rounded-lg bg-purple-100 px-3 py-2 text-sm text-purple-600">{subtitle}</div>}
      </div>
    </div>
  )
}

