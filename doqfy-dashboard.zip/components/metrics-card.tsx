import { Package, Clock, CheckCircle, XCircle } from "lucide-react"

interface MetricProps {
  icon: React.ReactNode
  label: string
  value: number
  trend: string
  trendValue: string
}

function MetricCard({ icon, label, value, trend, trendValue }: MetricProps) {
  return (
    <div className="rounded-lg bg-purple-50 p-4">
      <div className="mb-2 flex items-center gap-2">
        {icon}
        <span className="text-2xl font-bold">{value}</span>
      </div>
      <div className="text-sm text-gray-600">{label}</div>
      <div className="mt-2 flex items-center gap-1 text-xs">
        <span className={trend === "up" ? "text-green-600" : "text-red-600"}>{trendValue}</span>
      </div>
    </div>
  )
}

export function MetricsGrid() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <MetricCard
        icon={<Package className="h-5 w-5 text-purple-600" />}
        label="Total Orders"
        value={18}
        trend="up"
        trendValue="+2.4%"
      />
      <MetricCard
        icon={<Clock className="h-5 w-5 text-purple-600" />}
        label="In Progress"
        value={10}
        trend="up"
        trendValue="+2.4%"
      />
      <MetricCard
        icon={<CheckCircle className="h-5 w-5 text-purple-600" />}
        label="Completed Order"
        value={5}
        trend="up"
        trendValue="+3.4%"
      />
      <MetricCard
        icon={<XCircle className="h-5 w-5 text-purple-600" />}
        label="Cancelled Order"
        value={3}
        trend="up"
        trendValue="+3.5%"
      />
    </div>
  )
}

