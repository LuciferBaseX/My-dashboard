export function WelcomeCard() {
  return (
    <div className="rounded-lg bg-white p-6 shadow-sm">
      <div className="mb-4">
        <span className="text-sm text-gray-500">👋 Welcome back,</span>
        <h2 className="text-xl font-semibold">Michael</h2>
        <span className="text-xs text-gray-400">25 May, 2023 - Tuesday</span>
      </div>
      <div>
        <span className="text-sm text-gray-500">My Wallet</span>
        <div className="flex items-baseline gap-1">
          <span className="text-lg">₹</span>
          <span className="text-3xl font-bold">2,50,000</span>
        </div>
        <span className="text-xs text-gray-400">Current Balance</span>
      </div>
    </div>
  )
}

