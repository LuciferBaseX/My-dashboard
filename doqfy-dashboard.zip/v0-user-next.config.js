/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  images: {
    unoptimized: true,
  },
  assetPrefix: "/doqfy-dashboard/",
  basePath: "/doqfy-dashboard",
}

module.exports = nextConfig

