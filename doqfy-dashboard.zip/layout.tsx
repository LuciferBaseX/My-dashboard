import { BellIcon } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b bg-white">
        <div className="container flex h-16 items-center px-4">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
              DOQFY
            </span>
          </Link>
          <nav className="ml-8 flex gap-6">
            <Link href="#" className="text-sm font-medium hover:text-purple-600">
              Services
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-purple-600">
              User Management
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-purple-600">
              My Orders
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-purple-600">
              Reports
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-purple-600">
              Stamp Inventory
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-purple-600">
              Bar Codes
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-purple-600">
              Invoice
            </Link>
          </nav>
          <div className="ml-auto flex items-center gap-4">
            <button className="relative">
              <BellIcon className="h-5 w-5 text-gray-600" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] text-white">
                2
              </span>
            </button>
            <Avatar>
              <AvatarImage src="/placeholder.svg" />
              <AvatarFallback>MS</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>
      <main className="container px-4 py-8">{children}</main>
    </div>
  )
}

